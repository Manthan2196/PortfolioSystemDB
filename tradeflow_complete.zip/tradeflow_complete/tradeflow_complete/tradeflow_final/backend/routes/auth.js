// routes/auth.js  →  /api/auth

const router  = require('express').Router();
const { query } = require('../db');
const { signToken, requireAuth } = require('../middleware/auth');

/* POST /api/auth/login */
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const { rows } = await query(
      `SELECT user_id, name, email, password, kyc_status
       FROM users
       WHERE lower(email) = lower($1)`,
      [email.trim()]
    );

    const user = rows[0];

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // 🔥 Simple password check (NO bcrypt)
    if (password !== user.password) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // ✅ Success
    res.json({
      token: signToken(user),
      user: {
        id: user.user_id,
        email: user.email,
        name: user.name,
        role: 'USER'
      },
    });

  } catch (e) {
    console.error('[AUTH] login error:', e.message);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

/* GET /api/auth/me */
router.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;