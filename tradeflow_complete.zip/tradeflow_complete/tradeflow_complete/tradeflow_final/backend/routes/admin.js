// routes/admin.js  →  /api/admin   (ADMIN role only)
// Real schema:
//   system_logs(log_id, txn_id, operation, status, timestamp)
//   database_transactions(txn_id, user_id, txn_state, start_time, end_time)
//   locks(lock_id, txn_id, resource_type, lock_mode)
const router = require('express').Router();
const { query } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

router.use(requireAuth, requireRole('ADMIN'));

/* GET /api/admin/logs */
router.get('/logs', async (req, res) => {
  const { status, limit = 100 } = req.query;
  try {
    let sql = `
      SELECT l.log_id, l.txn_id, l.operation, l.status, l."timestamp",
             dt.user_id, u.name AS user_name
      FROM   system_logs l
      LEFT   JOIN database_transactions dt ON dt.txn_id = l.txn_id
      LEFT   JOIN users u ON u.user_id = dt.user_id
    `;
    const params = [];
    if (status && status !== 'ALL') {
      sql += ` WHERE upper(l.status) = $1`;
      params.push(status.toUpperCase());
    }
    sql += ` ORDER BY l."timestamp" DESC LIMIT $${params.length + 1}`;
    params.push(parseInt(limit));
    const { rows } = await query(sql, params);
    res.json({ logs: rows });
  } catch (e) {
    console.error('[ADMIN LOGS]', e.message);
    res.status(500).json({ error: 'Failed to fetch logs.' });
  }
});

/* GET /api/admin/db-transactions */
router.get('/db-transactions', async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT dt.txn_id, dt.user_id, u.name AS user_name,
             dt.txn_state, dt.start_time, dt.end_time,
             EXTRACT(EPOCH FROM (COALESCE(dt.end_time, NOW()) - dt.start_time)) * 1000 AS duration_ms
      FROM   database_transactions dt
      LEFT   JOIN users u ON u.user_id = dt.user_id
      ORDER  BY dt.start_time DESC
      LIMIT  100
    `);
    res.json({ transactions: rows });
  } catch (e) {
    console.error('[ADMIN DBTXN]', e.message);
    res.status(500).json({ error: 'Failed to fetch DB transactions.' });
  }
});

/* GET /api/admin/locks */
router.get('/locks', async (req, res) => {
  try {
    const recorded = await query(`
      SELECT lk.lock_id, lk.txn_id, lk.resource_type, lk.lock_mode,
             dt.txn_state, dt.user_id, u.name AS user_name
      FROM   locks lk
      LEFT   JOIN database_transactions dt ON dt.txn_id = lk.txn_id
      LEFT   JOIN users u ON u.user_id = dt.user_id
      ORDER  BY lk.lock_id DESC LIMIT 50
    `);
    // Live PG advisory / relation locks
    const live = await query(`
      SELECT pid, relation::regclass AS table_name, mode, granted,
             pg_blocking_pids(pid) AS blocked_by
      FROM   pg_locks
      WHERE  relation IS NOT NULL
        AND  relation::regclass::text NOT LIKE 'pg_%'
      LIMIT  20
    `).catch(() => ({ rows: [] }));

    res.json({ locks: recorded.rows, live_locks: live.rows });
  } catch (e) {
    console.error('[ADMIN LOCKS]', e.message);
    res.status(500).json({ error: 'Failed to fetch locks.' });
  }
});

/* GET /api/admin/stats */
router.get('/stats', async (req, res) => {
  try {
    const [[users],[orders],[trades],[errLogs]] = await Promise.all([
      query('SELECT COUNT(*) FROM users'),
      query("SELECT COUNT(*) FROM orders WHERE upper(order_status)='EXECUTED'"),
      query('SELECT COUNT(*), COALESCE(SUM(executed_price * executed_quantity),0) AS vol FROM trades'),
      query("SELECT COUNT(*) FROM system_logs WHERE upper(status)='FAILED'"),
    ].map(p => p.then(r => r.rows)));

    res.json({
      total_users:     parseInt(users.count),
      executed_orders: parseInt(orders.count),
      total_trades:    parseInt(trades.count),
      total_volume:    parseFloat(trades.vol),
      error_logs:      parseInt(errLogs.count),
    });
  } catch (e) {
    res.status(500).json({ error: 'Failed to fetch stats.' });
  }
});

/* GET /api/admin/dashboard/:userId — uses GetUserDashboard DB function */
router.get('/dashboard/:userId', async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM GetUserDashboard($1)', [req.params.userId]);
    res.json({ dashboard: rows[0] || null });
  } catch (e) {
    res.status(500).json({ error: 'Failed to fetch user dashboard.' });
  }
});

module.exports = router;
