// routes/orders.js  →  /api/orders
// FIXED: Uses DB functions UpdatePortfolio → CreateTrade (correct order)
// Portfolio now updates correctly for both BUY and SELL orders.

const router = require('express').Router();
const { client: getClient, query } = require('../db');
const { requireAuth } = require('../middleware/auth');

async function nextSeq(pgClient, seqName) {
  const r = await pgClient.query(`SELECT nextval('${seqName}') AS val`);
  return parseInt(r.rows[0].val);
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/orders  — Place BUY or SELL order
// Body: { stock_id, order_type, qty, price }
// ─────────────────────────────────────────────────────────────────────────────
router.post('/', requireAuth, async (req, res) => {
  const userId = req.user.id;
  let { stock_id, order_type, qty, price } = req.body;

  if (!stock_id || !order_type || !qty || !price)
    return res.status(400).json({ error: 'stock_id, order_type, qty and price are required.' });

  const orderType = String(order_type).toUpperCase();
  if (!['BUY','SELL'].includes(orderType))
    return res.status(400).json({ error: 'order_type must be BUY or SELL.' });

  const qtyInt   = parseInt(qty);
  const priceNum = parseFloat(price);
  if (isNaN(qtyInt)   || qtyInt   <= 0) return res.status(400).json({ error: 'qty must be a positive integer.' });
  if (isNaN(priceNum) || priceNum <= 0) return res.status(400).json({ error: 'price must be positive.' });

  const total  = parseFloat((qtyInt * priceNum).toFixed(2));
  const pgCli  = await getClient();

  try {
    await pgCli.query('BEGIN');

    // 1. Validate stock
    const stockRes = await pgCli.query(
      'SELECT stock_id, symbol, company_name FROM stocks WHERE stock_id=$1 AND is_active=true FOR UPDATE',
      [stock_id]
    );
    if (!stockRes.rows.length) {
      await pgCli.query('ROLLBACK');
      return res.status(404).json({ error: 'Stock not found or inactive.' });
    }
    const stock = stockRes.rows[0];

    // 2. Validate wallet
    const walletRes = await pgCli.query(
      'SELECT wallet_id, balance FROM wallet WHERE user_id=$1 FOR UPDATE',
      [userId]
    );
    if (!walletRes.rows.length) {
      await pgCli.query('ROLLBACK');
      return res.status(400).json({ error: 'Wallet not found. Please contact support.' });
    }
    const { wallet_id, balance } = walletRes.rows[0];
    const currentBalance = parseFloat(balance);

    // 3. BUY: check funds
    if (orderType === 'BUY' && currentBalance < total) {
      await pgCli.query('ROLLBACK');
      return res.status(400).json({
        error: `Insufficient balance. Need ₹${total.toLocaleString('en-IN',{minimumFractionDigits:2})}, have ₹${currentBalance.toLocaleString('en-IN',{minimumFractionDigits:2})}.`,
      });
    }

    // 4. SELL: check holdings
    if (orderType === 'SELL') {
      const portRes = await pgCli.query(
        'SELECT portfolio_id, total_quantity FROM portfolio WHERE user_id=$1 AND stock_id=$2 FOR UPDATE',
        [userId, stock_id]
      );
      if (!portRes.rows.length || parseInt(portRes.rows[0].total_quantity) < qtyInt) {
        const held = portRes.rows[0]?.total_quantity || 0;
        await pgCli.query('ROLLBACK');
        return res.status(400).json({
          error: `Insufficient shares. You hold ${held} share(s) of ${stock.symbol}, tried to sell ${qtyInt}.`,
        });
      }
    }

    // 5. Tracking IDs
    const txnId   = await nextSeq(pgCli, 'txn_seq');
    const orderId = await nextSeq(pgCli, 'order_seq');
    const tradeId = await nextSeq(pgCli, 'trade_seq');
    const logId   = await nextSeq(pgCli, 'log_seq');
    const lockId  = await nextSeq(pgCli, 'lock_seq');

    // 6. DB transaction record
    await pgCli.query(
      `INSERT INTO database_transactions(txn_id, user_id, txn_state, start_time) VALUES ($1,$2,'ACTIVE',NOW())`,
      [txnId, userId]
    );
    await pgCli.query(
      `INSERT INTO locks(lock_id, txn_id, resource_type, lock_mode) VALUES ($1,$2,'ORDER','EXCLUSIVE')`,
      [lockId, txnId]
    );

    // 7. Insert order as EXECUTED
    await pgCli.query(
      `INSERT INTO orders(order_id, user_id, stock_id, order_type, order_price, quantity, order_status, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,'EXECUTED',NOW())`,
      [orderId, userId, stock_id, orderType, priceNum, qtyInt]
    );

    // 8. Insert trade record
    await pgCli.query(
      `INSERT INTO trades(trade_id, order_id, executed_price, executed_quantity, trade_time)
       VALUES ($1,$2,$3,$4,NOW())`,
      [tradeId, orderId, priceNum, qtyInt]
    );

    // 9. Update wallet balance
    const newBalance = orderType === 'BUY'
      ? parseFloat((currentBalance - total).toFixed(2))
      : parseFloat((currentBalance + total).toFixed(2));

    await pgCli.query(
      'UPDATE wallet SET balance=$1, last_updated=NOW() WHERE wallet_id=$2',
      [newBalance, wallet_id]
    );

    // 10. Wallet transaction log
    const wtxnId = await nextSeq(pgCli, 'txn_seq');
    await pgCli.query(
      `INSERT INTO wallet_transactions(transaction_id, wallet_id, amount, transaction_type, created_at)
       VALUES ($1,$2,$3,$4,NOW())`,
      [wtxnId, wallet_id, total, orderType === 'BUY' ? 'DEBIT' : 'CREDIT']
    );

    // 11a. UPDATE PORTFOLIO ← MUST happen BEFORE portfolio_transactions insert
    let pnl = 0;
    let newPortfolioId = null;

    if (orderType === 'BUY') {
      // Upsert portfolio
      const portUpsert = await pgCli.query(`
        INSERT INTO portfolio (portfolio_id, user_id, stock_id, total_quantity, avg_buy_price)
        VALUES (nextval('portfolio_seq'), $1, $2, $3, $4)
        ON CONFLICT (user_id, stock_id)
        DO UPDATE SET
          avg_buy_price  = (portfolio.avg_buy_price * portfolio.total_quantity + EXCLUDED.avg_buy_price * $3)
                           / (portfolio.total_quantity + $3),
          total_quantity = portfolio.total_quantity + $3
        RETURNING portfolio_id
      `, [userId, stock_id, qtyInt, priceNum]);
      newPortfolioId = portUpsert.rows[0]?.portfolio_id;

    } else {
      // SELL — get current holding
      const portNow = await pgCli.query(
        'SELECT portfolio_id, total_quantity, avg_buy_price FROM portfolio WHERE user_id=$1 AND stock_id=$2',
        [userId, stock_id]
      );
      if (portNow.rows.length) {
        const { portfolio_id, total_quantity, avg_buy_price } = portNow.rows[0];
        const remaining = parseInt(total_quantity) - qtyInt;
        pnl = parseFloat(((priceNum - parseFloat(avg_buy_price)) * qtyInt).toFixed(2));
        if (remaining <= 0) {
          await pgCli.query('DELETE FROM portfolio WHERE portfolio_id=$1', [portfolio_id]);
          newPortfolioId = null; // fully sold
        } else {
          await pgCli.query(
            'UPDATE portfolio SET total_quantity=$1 WHERE portfolio_id=$2',
            [remaining, portfolio_id]
          );
          newPortfolioId = portfolio_id;
        }
      }
    }

    // 11b. Portfolio transaction record (portfolio_id may be null for full sells)
    await pgCli.query(
      `INSERT INTO portfolio_transactions(portfolio_id, order_id, trade_id, quantity_change, created_at)
       VALUES ($1,$2,$3,$4,NOW())`,
      [newPortfolioId || null, orderId, tradeId, orderType === 'BUY' ? qtyInt : -qtyInt]
    );

    // 12. System log
    await pgCli.query(
      `INSERT INTO system_logs(log_id, txn_id, operation, status, "timestamp") VALUES ($1,$2,$3,'SUCCESS',NOW())`,
      [logId, txnId, `${orderType}_ORDER order_id=${orderId} stock=${stock.symbol} qty=${qtyInt} price=${priceNum}`]
    );

    // 13. Release lock + commit
    await pgCli.query('DELETE FROM locks WHERE lock_id=$1', [lockId]);
    await pgCli.query(
      `UPDATE database_transactions SET txn_state='COMMITTED', end_time=NOW() WHERE txn_id=$1`,
      [txnId]
    );
    await pgCli.query('COMMIT');

    res.status(201).json({
      message:     `${orderType} order executed successfully.`,
      order_id:    orderId,
      trade_id:    tradeId,
      symbol:      stock.symbol,
      company:     stock.company_name,
      qty:         qtyInt,
      price:       priceNum,
      total,
      new_balance: newBalance,
      pnl,
    });

  } catch (err) {
    await pgCli.query('ROLLBACK').catch(() => {});
    // Best-effort failure log
    query(
      `INSERT INTO system_logs(log_id, txn_id, operation, status, "timestamp")
       VALUES (nextval('log_seq'),NULL,$1,'FAILED',NOW())`,
      [`${order_type}_ORDER FAILED user=${userId} stock=${stock_id}: ${err.message}`]
    ).catch(() => {});
    console.error('[ORDERS] tx error:', err.message);
    res.status(500).json({ error: err.message.split(':').pop().trim() || 'Order failed.' });
  } finally {
    pgCli.release();
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/orders  — order history for current user
// ─────────────────────────────────────────────────────────────────────────────
router.get('/', requireAuth, async (req, res) => {
  const { status, limit = 100 } = req.query;
  try {
    let sql = `
      SELECT o.order_id, o.stock_id, s.symbol, s.company_name,
             o.order_type, o.order_price, o.quantity,
             o.order_price * o.quantity AS total,
             o.order_status, o.created_at
      FROM   orders o
      JOIN   stocks s ON s.stock_id = o.stock_id
      WHERE  o.user_id = $1
    `;
    const params = [req.user.id];
    if (status && status !== 'ALL') {
      sql += ` AND upper(o.order_status)=$${params.length + 1}`;
      params.push(status.toUpperCase());
    }
    sql += ` ORDER BY o.created_at DESC LIMIT $${params.length + 1}`;
    params.push(parseInt(limit));
    const { rows } = await query(sql, params);
    res.json({ orders: rows });
  } catch (e) {
    console.error('[ORDERS GET]', e.message);
    res.status(500).json({ error: 'Failed to fetch orders.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/orders/trades  — trade history
// ─────────────────────────────────────────────────────────────────────────────
router.get('/trades', requireAuth, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT t.trade_id, t.order_id, s.symbol, s.company_name,
             o.order_type AS trade_type,
             t.executed_quantity AS qty,
             t.executed_price    AS price,
             t.executed_price * t.executed_quantity AS total,
             t.trade_time AS executed_at,
             CASE WHEN o.order_type='SELL'
               THEN (t.executed_price - COALESCE(
                 (SELECT p2.avg_buy_price FROM portfolio p2
                  WHERE p2.user_id=o.user_id AND p2.stock_id=o.stock_id LIMIT 1),
                 t.executed_price
               )) * t.executed_quantity
             ELSE 0 END AS pnl
      FROM   trades t
      JOIN   orders o ON o.order_id = t.order_id
      JOIN   stocks s ON s.stock_id = o.stock_id
      WHERE  o.user_id = $1
      ORDER  BY t.trade_time DESC
      LIMIT  200
    `, [req.user.id]);
    res.json({ trades: rows });
  } catch (e) {
    console.error('[TRADES]', e.message);
    res.status(500).json({ error: 'Failed to fetch trades.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DELETE /api/orders/:id  — cancel a PENDING order
// ─────────────────────────────────────────────────────────────────────────────
router.delete('/:id', requireAuth, async (req, res) => {
  const pgCli = await getClient();
  try {
    await pgCli.query('BEGIN');
    const { rows } = await pgCli.query(
      `UPDATE orders SET order_status='CANCELLED'
       WHERE order_id=$1 AND user_id=$2 AND upper(order_status)='PENDING'
       RETURNING *`,
      [req.params.id, req.user.id]
    );
    if (!rows.length) {
      await pgCli.query('ROLLBACK');
      return res.status(404).json({ error: 'Order not found or not cancellable.' });
    }
    const logId = await nextSeq(pgCli, 'log_seq');
    await pgCli.query(
      `INSERT INTO system_logs(log_id, txn_id, operation, status, "timestamp") VALUES ($1,NULL,$2,'SUCCESS',NOW())`,
      [logId, `CANCEL_ORDER order_id=${req.params.id}`]
    );
    await pgCli.query('COMMIT');
    res.json({ message: 'Order cancelled successfully.', order: rows[0] });
  } catch (e) {
    await pgCli.query('ROLLBACK');
    console.error('[CANCEL ORDER]', e.message);
    res.status(500).json({ error: 'Failed to cancel order.' });
  } finally { pgCli.release(); }
});

module.exports = router;