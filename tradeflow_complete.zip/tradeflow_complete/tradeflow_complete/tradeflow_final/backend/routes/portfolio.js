// routes/portfolio.js  →  /api/portfolio
// Uses v_portfolio_detail view + GetPortfolioValue + GetProfitLoss DB functions

const router = require('express').Router();
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');

/* GET /api/portfolio */
router.get('/', requireAuth, async (req, res) => {
  try {
    const [portRes, aggRes] = await Promise.all([
      query(`
        SELECT * FROM v_portfolio_detail
        WHERE user_id = $1
        ORDER BY current_value DESC
      `, [req.user.id]),
      query(`
        SELECT
          GetPortfolioValue($1) AS portfolio_value,
          GetProfitLoss($1)     AS profit_loss
      `, [req.user.id]),
    ]);

    const agg = aggRes.rows[0];
    res.json({
      portfolio:       portRes.rows,
      portfolio_value: parseFloat(agg.portfolio_value || 0),
      profit_loss:     parseFloat(agg.profit_loss     || 0),
    });
  } catch (e) {
    console.error('[PORTFOLIO]', e.message);
    res.status(500).json({ error: 'Failed to fetch portfolio.' });
  }
});

/* GET /api/portfolio/summary — uses GetUserDashboard DB function */
router.get('/summary', requireAuth, async (req, res) => {
  try {
    const { rows } = await query(`SELECT * FROM GetUserDashboard($1)`, [req.user.id]);
    res.json({ summary: rows[0] || {} });
  } catch (e) {
    console.error('[PORTFOLIO SUMMARY]', e.message);
    res.status(500).json({ error: 'Failed to fetch portfolio summary.' });
  }
});

module.exports = router;