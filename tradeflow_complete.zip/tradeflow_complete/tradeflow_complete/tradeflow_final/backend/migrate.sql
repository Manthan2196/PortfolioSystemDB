-- ═══════════════════════════════════════════════════════════════════
--  TradeFlow — Auth Migration
--  Run AFTER restoring PortfolioDb2303-290326.sql
--  Adds login/role support to the existing Users table without
--  touching any existing column, constraint, or function.
-- ═══════════════════════════════════════════════════════════════════

-- ── Sequences needed for new rows (existing seqs already in dump) ──
CREATE SEQUENCE IF NOT EXISTS user_id_seq START 1001 INCREMENT 1;

-- ── Add auth columns to users (idempotent) ────────────────────────
ALTER TABLE public.users
  ADD COLUMN IF NOT EXISTS email_addr   VARCHAR(120) UNIQUE,
  ADD COLUMN IF NOT EXISTS password_hash TEXT,
  ADD COLUMN IF NOT EXISTS role         VARCHAR(10)  DEFAULT 'USER'
    CHECK (role IN ('USER','ADMIN'));

-- ── Seed two demo accounts (password = "password" for both) ───────
-- bcrypt hash of "password" (cost=10)
INSERT INTO public.users (user_id, name, email, email_addr, password_hash, role, kyc_status)
VALUES
  (1001, 'Demo User',  'demo@tradeflow.in',  'demo@tradeflow.in',  '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'USER',  'VERIFIED'),
  (1002, 'Admin User', 'admin@tradeflow.in', 'admin@tradeflow.in', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN', 'VERIFIED')
ON CONFLICT (user_id) DO UPDATE
  SET email_addr    = EXCLUDED.email_addr,
      password_hash = EXCLUDED.password_hash,
      role          = EXCLUDED.role;

-- ── Seed wallets for demo accounts ───────────────────────────────
INSERT INTO public.wallet (wallet_id, user_id, balance)
VALUES
  (9001, 1001, 150000.00),
  (9002, 1002, 500000.00)
ON CONFLICT (wallet_id) DO NOTHING;

-- ── Seed stock_price_history for the first 10 stocks if empty ────
-- (gives the chart something to render)
INSERT INTO public.stock_price_history (price_id, stock_id, price, price_timestamp)
SELECT
  5000 + (s.rn * 31) + d.day_offset,
  s.stock_id,
  s.base_price * (0.90 + (random() * 0.20)),
  NOW() - ((30 - d.day_offset) || ' days')::interval
FROM (
  SELECT stock_id, row_number() OVER () AS rn,
         COALESCE((SELECT price FROM public.stock_price_history WHERE stock_id = st.stock_id LIMIT 1), 1000) AS base_price
  FROM   public.stocks st
  WHERE  is_active = true
  LIMIT  10
) s
CROSS JOIN (
  SELECT generate_series(0, 30) AS day_offset
) d
ON CONFLICT DO NOTHING;

-- ── Helper view: latest stock price ───────────────────────────────
CREATE OR REPLACE VIEW public.v_stock_latest_price AS
SELECT DISTINCT ON (stock_id)
  stock_id,
  price         AS latest_price,
  price_timestamp
FROM   public.stock_price_history
ORDER  BY stock_id, price_timestamp DESC;

-- ── Helper view: portfolio with current value ──────────────────────
CREATE OR REPLACE VIEW public.v_portfolio_detail AS
SELECT
  p.portfolio_id,
  p.user_id,
  p.stock_id,
  s.symbol,
  s.company_name,
  s.sector,
  p.total_quantity,
  p.avg_buy_price,
  COALESCE(lp.latest_price, p.avg_buy_price)                          AS current_price,
  p.total_quantity * COALESCE(lp.latest_price, p.avg_buy_price)       AS current_value,
  p.total_quantity * p.avg_buy_price                                   AS invested_value,
  (COALESCE(lp.latest_price, p.avg_buy_price) - p.avg_buy_price)
    * p.total_quantity                                                  AS unrealized_pnl,
  CASE WHEN p.avg_buy_price > 0 THEN
    ((COALESCE(lp.latest_price, p.avg_buy_price) - p.avg_buy_price)
      / p.avg_buy_price * 100)
  ELSE 0 END                                                           AS pnl_pct
FROM   public.portfolio p
JOIN   public.stocks    s  ON s.stock_id = p.stock_id
LEFT   JOIN public.v_stock_latest_price lp ON lp.stock_id = p.stock_id
WHERE  p.total_quantity > 0;
