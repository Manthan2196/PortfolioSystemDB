// db.js — PostgreSQL connection pool
// Supports both local PostgreSQL and Supabase (via SSL).
// Column names match the real dump schema exactly.

require('dotenv').config();   // FIRST

console.log("ENV URL:", process.env.DATABASE_URL);  // THEN use it

const { Pool } = require('pg');

// ── Determine whether to use SSL ─────────────────────────────
// Supabase requires SSL. Local dev usually doesn't.
// Set USE_SSL=true in .env to enable, or it auto-detects Supabase
// by checking if DB_HOST contains "supabase.com".
const host       = process.env.DB_HOST || 'localhost';
const useSSL     = process.env.USE_SSL === 'true' ||
                   host.includes('supabase.com') ||
                   host.includes('supabase.co');

const sslConfig  = useSSL ? { rejectUnauthorized: false } : false;

// ── Supabase connection string support ───────────────────────
// If DATABASE_URL is set (Supabase "Connection string" format),
// use it directly. Otherwise fall back to individual variables.
const poolConfig = process.env.DATABASE_URL
  ? {
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false },   // always needed for Supabase URLs
      max:                      10,          // Supabase free tier has a connection limit
      idleTimeoutMillis:    30_000,
      connectionTimeoutMillis: 5_000,
    }
  : {
      host,
      port:     parseInt(process.env.DB_PORT || '5432'),
      database: process.env.DB_NAME     || 'portfoliodb',
      user:     process.env.DB_USER     || 'postgres',
      password: process.env.DB_PASSWORD || 'postgres',
      ssl:      sslConfig,
      max:      20,
      idleTimeoutMillis:    30_000,
      connectionTimeoutMillis: 5_000,
    };

const pool = new Pool(poolConfig);

pool.on('error', (err) => {
  console.error('[DB] Unexpected pool error:', err.message);
});

// ── Connection health check — called once on startup ─────────
const testConnection = async () => {
  try {
    const client = await pool.connect();
    const res    = await client.query('SELECT version()');
    client.release();
    const ver = res.rows[0].version.split(' ').slice(0, 2).join(' ');
    console.log(`[DB] Connected ✅  ${ver}`);
    console.log(`[DB] SSL: ${useSSL ? 'enabled' : 'disabled'} | Host: ${host}`);
  } catch (err) {
    console.error('[DB] Connection FAILED ❌:', err.message);
    console.error('[DB] Check your .env DB credentials and ensure the database is reachable.');
    // Don't crash immediately — let Express start so /api/health can report the error
  }
};

testConnection();

// ── Exports ──────────────────────────────────────────────────
const query  = (text, params) => pool.query(text, params);
const client = ()              => pool.connect();

module.exports = { pool, query, client };
