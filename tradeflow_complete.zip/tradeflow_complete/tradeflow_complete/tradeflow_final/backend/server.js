// server.js — TradeFlow Express Server
require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const { pool } = require('./db');   // import pool for health check

const app  = express();
const PORT = process.env.PORT || 4000;

app.use(cors({
  origin:         process.env.FRONTEND_URL || '*',
  methods:        ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
app.use(express.json());
app.use((req, _res, next) => {
  if (process.env.NODE_ENV !== 'production')
    console.log(`[${new Date().toISOString().slice(11,19)}] ${req.method} ${req.path}`);
  next();
});

app.use('/api/auth',      require('./routes/auth'));
app.use('/api/stocks',    require('./routes/stocks'));
app.use('/api/orders',    require('./routes/orders'));
app.use('/api/portfolio', require('./routes/portfolio'));
app.use('/api/wallet',    require('./routes/wallet'));
app.use('/api/admin',     require('./routes/admin'));

// ── Health check — also probes DB ────────────────────────────
app.get('/api/health', async (_req, res) => {
  let dbStatus = 'ok';
  let dbLatency = null;
  try {
    const t0 = Date.now();
    await pool.query('SELECT 1');
    dbLatency = Date.now() - t0;
  } catch (e) {
    dbStatus = 'error: ' + e.message;
  }
  res.json({
    status:    'ok',
    ts:        new Date().toISOString(),
    db:        dbStatus,
    db_latency_ms: dbLatency,
    env:       process.env.NODE_ENV || 'development',
  });
});

app.use((err, _req, res, _next) => {
  console.error('[SERVER]', err.message);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`✅ TradeFlow API → http://localhost:${PORT}`);
  console.log(`   Health check → http://localhost:${PORT}/api/health`);
});
