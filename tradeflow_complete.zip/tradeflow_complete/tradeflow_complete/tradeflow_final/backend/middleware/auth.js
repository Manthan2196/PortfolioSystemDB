// middleware/auth.js
const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'tradeflow_dev_secret';

const requireAuth = (req, res, next) => {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Authentication required.' });
  try {
    req.user = jwt.verify(token, SECRET);   // { id, email, name, role }
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
};

const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user?.role))
    return res.status(403).json({ error: `Requires role: ${roles.join(' or ')}` });
  next();
};

const signToken = (user) =>
  jwt.sign(
    { id: user.user_id, email: user.email_addr, name: user.name, role: user.role || 'USER' },
    SECRET,
    { expiresIn: '8h' }
  );

module.exports = { requireAuth, requireRole, signToken };
