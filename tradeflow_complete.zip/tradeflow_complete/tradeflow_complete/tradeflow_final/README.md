# TradeFlow — Full-Stack Stock Trading Platform

A production-grade stock trading system with:
- **PostgreSQL** database (real schema with sequences, functions, views)
- **Node.js + Express** backend (atomic SQL transactions, JWT auth, role-based access)
- **React** frontend (single HTML file, no build tools required)
- **Supabase** support (or local PostgreSQL)

---

## 📁 Project Structure

```
tradeflow/
├── backend/
│   ├── server.js              ← Express entry point
│   ├── db.js                  ← PostgreSQL pool (Supabase + local)
│   ├── package.json
│   ├── .env.example           ← Copy to .env and fill in credentials
│   ├── migrate.sql            ← Run this AFTER restoring the DB dump
│   ├── middleware/
│   │   └── auth.js            ← JWT verify + requireRole guard
│   └── routes/
│       ├── auth.js            ← POST /api/auth/login
│       ├── stocks.js          ← GET /api/stocks, /api/stocks/:id/history
│       ├── orders.js          ← POST/GET/DELETE /api/orders (atomic BUY/SELL)
│       ├── portfolio.js       ← GET /api/portfolio (uses DB views + functions)
│       ├── wallet.js          ← GET/POST /api/wallet/* (uses CreditWallet/DebitWallet)
│       └── admin.js           ← GET /api/admin/* (ADMIN role only)
└── frontend/
    └── index.html             ← Complete React app (open directly in browser)
```

---

## 🚀 Quick Setup

### Step 1 — Database

**Option A: Local PostgreSQL**
```bash
createdb portfoliodb
psql -d portfoliodb -f PortfolioDb2303-290326.sql   # your existing dump
psql -d portfoliodb -f backend/migrate.sql           # adds auth columns + views
```

**Option B: Supabase**
1. Create project at https://supabase.com
2. SQL Editor → run contents of `PortfolioDb2303-290326.sql`
3. SQL Editor → run contents of `backend/migrate.sql`
4. Copy credentials from Project Settings → Database

### Step 2 — Backend

```bash
cd backend
cp .env.example .env
# Edit .env with your credentials (see instructions inside)
npm install
npm run dev
```

Verify: http://localhost:4000/api/health should return `{ "db": "ok" }`

### Step 3 — Frontend

Open `frontend/index.html` directly in your browser. No build step needed.

---

## 🔑 Demo Accounts

| Role  | Email                  | Password   |
|-------|------------------------|------------|
| USER  | demo@tradeflow.in      | `password` |
| ADMIN | admin@tradeflow.in     | `password` |

---

## 🌐 API Endpoints

| Method   | Path                            | Auth  | Role  | Description                    |
|----------|---------------------------------|-------|-------|--------------------------------|
| POST     | /api/auth/login                 | ✗     | Any   | Login → JWT token              |
| GET      | /api/auth/me                    | JWT   | Any   | Current user                   |
| GET      | /api/stocks                     | JWT   | Any   | All active stocks              |
| GET      | /api/stocks/:id/history?days=30 | JWT   | Any   | Price history                  |
| POST     | /api/orders                     | JWT   | Any   | Place BUY or SELL order        |
| GET      | /api/orders                     | JWT   | Any   | Order history                  |
| GET      | /api/orders/trades              | JWT   | Any   | Trade history                  |
| DELETE   | /api/orders/:id                 | JWT   | Any   | Cancel PENDING order           |
| GET      | /api/portfolio                  | JWT   | Any   | Portfolio + P&L                |
| GET      | /api/wallet                     | JWT   | Any   | Wallet balance                 |
| GET      | /api/wallet/transactions        | JWT   | Any   | Transaction history            |
| POST     | /api/wallet/deposit             | JWT   | Any   | Deposit funds                  |
| POST     | /api/wallet/withdraw            | JWT   | Any   | Withdraw funds                 |
| GET      | /api/admin/logs                 | JWT   | ADMIN | System logs                    |
| GET      | /api/admin/db-transactions      | JWT   | ADMIN | DB transaction log             |
| GET      | /api/admin/locks                | JWT   | ADMIN | Lock manager + live PG locks   |
| GET      | /api/admin/stats                | JWT   | ADMIN | Platform statistics            |
| GET      | /api/health                     | ✗     | Any   | Server + DB health check       |

---

## 🗄️ Key Database Objects Used

**Tables (from dump — untouched):**
`users`, `wallet`, `wallet_transactions`, `stocks`, `stock_price_history`, `orders`, `trades`, `portfolio`, `database_transactions`, `locks`, `system_logs`

**Existing functions preserved:**
`GetPortfolioValue`, `GetProfitLoss`, `GetUserDashboard`, `GetWalletSummary`, `GetUserOrderSummary`, `CreditWallet`, `DebitWallet`, `PlaceOrder`, `ExecuteTrade`, `UpdatePortfolio`, `AcquireLock`, `ReleaseLock`, etc.

**Views added by migrate.sql:**
- `v_stock_latest_price` — latest price per stock from price history
- `v_portfolio_detail` — portfolio holdings with current value, P&L, P&L %

---

## 🎨 Frontend Features

- **Login** — JWT auth, session persist in localStorage, auto-restore on reload
- **Dashboard** — animated counters, portfolio P&L chart, top holdings, recent orders
- **Markets** — multi-stock comparison chart (up to 6), single-stock mode, 7/14/30/90 day selector, sparklines, search + sort
- **Place Order** — BUY/SELL toggle, MARKET/LIMIT/SL order types, real-time wallet usage bar, holdings check for SELL
- **Portfolio** — donut allocation chart, invested vs current bar chart, holdings detail table
- **Wallet** — animated balance, deposit/withdraw with quick amounts, balance history chart, transaction list
- **Orders & Trades** — sort asc/desc, status filters, cancel pending orders, separate trades tab with P&L
- **Admin Logs** — system logs, DB transaction log with flow diagram, live PostgreSQL lock inspector

**UI behaviors:**
- Skeleton shimmer loaders on every data section
- Smooth `fadeUp` animations on all page content
- 5-second polling for wallet balance + stock prices
- Retry mechanism on API failures (1 retry with backoff)
- Empty states for all zero-data scenarios
- Toast notifications (6-second auto-dismiss)
- Dark/light mode toggle
- Fully responsive (mobile sidebar)
- Animated number counters on balance/portfolio values

---

## ⚙️ Environment Variables

See `.env.example` for full documentation with Supabase setup instructions.

```env
PORT=4000
NODE_ENV=development
JWT_SECRET=your_secret_here
DB_HOST=localhost          # or your Supabase host
DB_PORT=5432
DB_NAME=portfoliodb        # or postgres for Supabase
DB_USER=postgres
DB_PASSWORD=your_password
# USE_SSL=true             # uncomment for Supabase
# DATABASE_URL=...         # alternative: full Supabase connection string
```
