// routes/portfolio.js  →  /api/portfolio
// Real schema: portfolio(portfolio_id, user_id, stock_id, total_quantity, avg_buy_price)
// Uses v_portfolio_detail view (created in migrate.sql)
// Also calls GetPortfolioValue and GetProfitLoss DB functions
const router = require('express').Router();
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');

/* GET /api/portfolio */
router.get('/', requireAuth, async (req, res) => {
  try {
    // Use the view for full detail
    const { rows } = await query(`
      SELECT * FROM v_portfolio_detail WHERE user_id = $1 ORDER BY current_value DESC
    `, [req.user.id]);

    // Also call the DB functions for aggregate values
    const aggRes = await query(`
      SELECT
        GetPortfolioValue($1) AS portfolio_value,
        GetProfitLoss($1)     AS profit_loss
    `, [req.user.id]);

    const agg = aggRes.rows[0];
    res.json({
      portfolio:      rows,
      portfolio_value: parseFloat(agg.portfolio_value || 0),
      profit_loss:     parseFloat(agg.profit_loss     || 0),
    });
  } catch (e) {
    console.error('[PORTFOLIO]', e.message);
    res.status(500).json({ error: 'Failed to fetch portfolio.' });
  }
});

module.exports = router;
