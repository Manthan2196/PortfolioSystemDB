// routes/wallet.js  →  /api/wallet
// Real schema:
//   wallet(wallet_id INT, user_id INT, balance NUMERIC(12,2), last_updated TIMESTAMP)
//   wallet_transactions(wallet_id INT, transaction_id INT,
//                       amount NUMERIC(10,2), transaction_type VARCHAR(6), created_at)
//   Constraint: amount > 0, transaction_type IN ('CREDIT','DEBIT')
// DB functions: CreditWallet(user_id, amount), DebitWallet(user_id, amount)
//               GetWalletSummary(user_id)
const router = require('express').Router();
const { query, client: getClient } = require('../db');
const { requireAuth } = require('../middleware/auth');

/* GET /api/wallet */
router.get('/', requireAuth, async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT wallet_id, balance, last_updated FROM wallet WHERE user_id=$1',
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Wallet not found.' });
    res.json({ wallet: rows[0] });
  } catch (e) {
    console.error('[WALLET]', e.message);
    res.status(500).json({ error: 'Failed to fetch wallet.' });
  }
});

/* GET /api/wallet/summary  — uses DB function GetWalletSummary */
router.get('/summary', requireAuth, async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM GetWalletSummary($1)', [req.user.id]);
    res.json({ summary: rows });
  } catch (e) {
    console.error('[WALLET SUMMARY]', e.message);
    res.status(500).json({ error: 'Failed to fetch wallet summary.' });
  }
});

/* GET /api/wallet/transactions */
router.get('/transactions', requireAuth, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT wt.transaction_id, wt.amount, wt.transaction_type, wt.created_at,
             w.balance AS current_balance
      FROM   wallet_transactions wt
      JOIN   wallet w ON w.wallet_id = wt.wallet_id
      WHERE  w.user_id = $1
      ORDER  BY wt.created_at DESC
      LIMIT  100
    `, [req.user.id]);
    res.json({ transactions: rows });
  } catch (e) {
    console.error('[WALLET TXN]', e.message);
    res.status(500).json({ error: 'Failed to fetch transactions.' });
  }
});

/* POST /api/wallet/deposit */
router.post('/deposit', requireAuth, async (req, res) => {
  const amt = parseFloat(req.body.amount);
  if (isNaN(amt) || amt <= 0)
    return res.status(400).json({ error: 'Amount must be positive.' });
  if (amt > 1_000_000)
    return res.status(400).json({ error: 'Max deposit ₹10,00,000 per transaction.' });

  const pgCli = await getClient();
  try {
    await pgCli.query('BEGIN');
    // Use existing DB function CreditWallet (it also logs the wallet_transaction)
    await pgCli.query('SELECT CreditWallet($1, $2)', [req.user.id, amt]);
    const r = await pgCli.query('SELECT balance FROM wallet WHERE user_id=$1', [req.user.id]);
    await pgCli.query('COMMIT');
    res.json({ message: `₹${amt.toLocaleString('en-IN')} deposited successfully.`, balance: parseFloat(r.rows[0].balance) });
  } catch (e) {
    await pgCli.query('ROLLBACK');
    console.error('[DEPOSIT]', e.message);
    res.status(500).json({ error: 'Deposit failed. ' + e.message });
  } finally { pgCli.release(); }
});

/* POST /api/wallet/withdraw */
router.post('/withdraw', requireAuth, async (req, res) => {
  const amt = parseFloat(req.body.amount);
  if (isNaN(amt) || amt <= 0)
    return res.status(400).json({ error: 'Amount must be positive.' });

  const pgCli = await getClient();
  try {
    await pgCli.query('BEGIN');
    const r = await pgCli.query('SELECT balance FROM wallet WHERE user_id=$1 FOR UPDATE', [req.user.id]);
    const bal = parseFloat(r.rows[0]?.balance || 0);
    if (amt > bal) {
      await pgCli.query('ROLLBACK');
      return res.status(400).json({ error: `Insufficient balance. Available ₹${bal.toLocaleString('en-IN',{minimumFractionDigits:2})}.` });
    }
    // Use existing DB function DebitWallet
    await pgCli.query('SELECT DebitWallet($1, $2)', [req.user.id, amt]);
    const updated = await pgCli.query('SELECT balance FROM wallet WHERE user_id=$1', [req.user.id]);
    await pgCli.query('COMMIT');
    res.json({ message: `₹${amt.toLocaleString('en-IN')} withdrawn.`, balance: parseFloat(updated.rows[0].balance) });
  } catch (e) {
    await pgCli.query('ROLLBACK');
    console.error('[WITHDRAW]', e.message);
    res.status(500).json({ error: 'Withdrawal failed. ' + e.message });
  } finally { pgCli.release(); }
});

module.exports = router;
