// routes/orders.js  →  /api/orders
//
// Real DB schema (from actual pg_dump):
//   orders(order_id INT PK, user_id INT, stock_id INT,
//          order_type VARCHAR(4), order_price NUMERIC(10,2),
//          quantity INT, order_status VARCHAR(10), created_at TIMESTAMP)
//   trades(order_id INT, trade_id INT,
//          executed_price NUMERIC(10,2), executed_quantity INT, trade_time TIMESTAMP)
//   portfolio(portfolio_id INT, user_id INT, stock_id INT,
//             total_quantity INT, avg_buy_price NUMERIC(10,2))
//   wallet(wallet_id INT, user_id INT, balance NUMERIC(12,2), last_updated TIMESTAMP)
//   wallet_transactions(wallet_id INT, transaction_id INT,
//                       amount NUMERIC(10,2), transaction_type VARCHAR(6), created_at)
//   database_transactions(txn_id INT, user_id INT, txn_state VARCHAR(10),
//                         start_time TIMESTAMP, end_time TIMESTAMP)
//   locks(lock_id INT, txn_id INT, resource_type TEXT, lock_mode VARCHAR(10))
//   system_logs(log_id INT, txn_id INT, operation TEXT, status TEXT, timestamp TIMESTAMP)
//
// Sequences (from dump): order_seq, trade_seq, lock_seq, txn_seq, log_seq, portfolio_seq

const router = require('express').Router();
const { client: getClient, query } = require('../db');
const { requireAuth } = require('../middleware/auth');

// ── helpers ──────────────────────────────────────────────────────
async function nextSeq(pgClient, seqName) {
  const r = await pgClient.query(`SELECT nextval('${seqName}') AS val`);
  return parseInt(r.rows[0].val);
}

async function walletIdFor(pgClient, userId) {
  const r = await pgClient.query('SELECT wallet_id FROM wallet WHERE user_id=$1', [userId]);
  if (!r.rows.length) throw new Error('Wallet not found for user.');
  return r.rows[0].wallet_id;
}

// ─────────────────────────────────────────────────────────────────
// POST /api/orders  — BUY or SELL
// Body: { stock_id, order_type, qty, price }
// ─────────────────────────────────────────────────────────────────
router.post('/', requireAuth, async (req, res) => {
  const userId = req.user.id;
  const { stock_id, order_type, qty, price } = req.body;

  // Input validation
  if (!stock_id || !order_type || !qty || !price)
    return res.status(400).json({ error: 'stock_id, order_type, qty and price are required.' });
  if (!['BUY', 'SELL'].includes(String(order_type).toUpperCase()))
    return res.status(400).json({ error: 'order_type must be BUY or SELL.' });

  const orderType = String(order_type).toUpperCase();
  const qtyInt    = parseInt(qty);
  const priceNum  = parseFloat(price);
  if (isNaN(qtyInt)   || qtyInt   <= 0) return res.status(400).json({ error: 'qty must be a positive integer.' });
  if (isNaN(priceNum) || priceNum <= 0) return res.status(400).json({ error: 'price must be positive.' });

  const total   = parseFloat((qtyInt * priceNum).toFixed(2));
  const startMs = Date.now();
  const pgCli   = await getClient();

  try {
    await pgCli.query('BEGIN');

    // 1. Lock stock row
    const stockRes = await pgCli.query(
      'SELECT stock_id, symbol, company_name FROM stocks WHERE stock_id=$1 AND is_active=true FOR UPDATE',
      [stock_id]
    );
    if (!stockRes.rows.length) { await pgCli.query('ROLLBACK'); return res.status(404).json({ error: 'Stock not found.' }); }
    const stock = stockRes.rows[0];

    // 2. Lock wallet row
    const walletRes = await pgCli.query(
      'SELECT wallet_id, balance FROM wallet WHERE user_id=$1 FOR UPDATE',
      [userId]
    );
    if (!walletRes.rows.length) { await pgCli.query('ROLLBACK'); return res.status(400).json({ error: 'Wallet not found.' }); }
    const { wallet_id, balance } = walletRes.rows[0];
    const currentBalance = parseFloat(balance);

    // 3. BUY validation
    if (orderType === 'BUY' && currentBalance < total) {
      await pgCli.query('ROLLBACK');
      return res.status(400).json({
        error: `Insufficient balance. Need ₹${total.toLocaleString('en-IN',{minimumFractionDigits:2})}, have ₹${currentBalance.toLocaleString('en-IN',{minimumFractionDigits:2})}.`,
      });
    }

    // 4. SELL validation — lock portfolio row
    let portfolioRow = null;
    if (orderType === 'SELL') {
      const portRes = await pgCli.query(
        'SELECT portfolio_id, total_quantity, avg_buy_price FROM portfolio WHERE user_id=$1 AND stock_id=$2 FOR UPDATE',
        [userId, stock_id]
      );
      if (!portRes.rows.length || parseInt(portRes.rows[0].total_quantity) < qtyInt) {
        const held = portRes.rows[0]?.total_quantity || 0;
        await pgCli.query('ROLLBACK');
        return res.status(400).json({
          error: `Insufficient shares. You hold ${held} share(s) of ${stock.symbol}, tried to sell ${qtyInt}.`,
        });
      }
      portfolioRow = portRes.rows[0];
    }

    // 5. Record a database_transaction entry (using existing DB function pattern)
    const txnId    = await nextSeq(pgCli, 'txn_seq');
    const orderId  = await nextSeq(pgCli, 'order_seq');
    const tradeId  = await nextSeq(pgCli, 'trade_seq');
    const logId    = await nextSeq(pgCli, 'log_seq');
    const lockId   = await nextSeq(pgCli, 'lock_seq');

    await pgCli.query(
      `INSERT INTO database_transactions(txn_id, user_id, txn_state, start_time)
       VALUES ($1,$2,'ACTIVE',NOW())`,
      [txnId, userId]
    );

    // 6. Acquire lock record
    await pgCli.query(
      `INSERT INTO locks(lock_id, txn_id, resource_type, lock_mode)
       VALUES ($1,$2,'ORDER','EXCLUSIVE')`,
      [lockId, txnId]
    );

    // 7. Insert order  (real schema: order_status check allows PENDING|EXECUTED|CANCELLED)
    await pgCli.query(
      `INSERT INTO orders(order_id, user_id, stock_id, order_type, order_price, quantity, order_status, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,'EXECUTED',NOW())`,
      [orderId, userId, stock_id, orderType, priceNum, qtyInt]
    );

    // 8. Insert trade  (real schema: trades has no user_id or pnl column)
    await pgCli.query(
      `INSERT INTO trades(order_id, trade_id, executed_price, executed_quantity, trade_time)
       VALUES ($1,$2,$3,$4,NOW())`,
      [orderId, tradeId, priceNum, qtyInt]
    );

    // 9. Update wallet balance
    const newBalance = orderType === 'BUY'
      ? parseFloat((currentBalance - total).toFixed(2))
      : parseFloat((currentBalance + total).toFixed(2));

    await pgCli.query(
      'UPDATE wallet SET balance=$1, last_updated=NOW() WHERE wallet_id=$2',
      [newBalance, wallet_id]
    );

    // 10. Log wallet transaction  (amount must be > 0 per constraint)
    const wtxnId = await nextSeq(pgCli, 'txn_seq');
    await pgCli.query(
      `INSERT INTO wallet_transactions(wallet_id, transaction_id, amount, transaction_type, created_at)
       VALUES ($1,$2,$3,$4,NOW())`,
      [wallet_id, wtxnId, total, orderType === 'BUY' ? 'DEBIT' : 'CREDIT']
    );

    // 11. Update portfolio
    let pnl = 0;

    if (orderType === 'BUY') {
      await pgCli.query(`
        INSERT INTO portfolio (user_id, stock_id, total_quantity, avg_buy_price)
        VALUES ($1, $2, $3, $4)
        ON CONFLICT (user_id, stock_id)
        DO UPDATE SET
          total_quantity = portfolio.total_quantity + EXCLUDED.total_quantity,
          avg_buy_price = (
            (portfolio.avg_buy_price * portfolio.total_quantity +
            EXCLUDED.avg_buy_price * EXCLUDED.total_quantity)
            / (portfolio.total_quantity + EXCLUDED.total_quantity)
          )
      `, [userId, stock_id, qtyInt, priceNum]);

    } else {
      // SELL
      const avgBuy = parseFloat(portfolioRow.avg_buy_price);
      pnl = parseFloat(((priceNum - avgBuy) * qtyInt).toFixed(2));

      const remaining = parseInt(portfolioRow.total_quantity) - qtyInt;

      if (remaining <= 0) {
        await pgCli.query(
          'DELETE FROM portfolio WHERE user_id=$1 AND stock_id=$2',
          [userId, stock_id]
        );
      } else {
        await pgCli.query(
          'UPDATE portfolio SET total_quantity=$1 WHERE user_id=$2 AND stock_id=$3',
          [remaining, userId, stock_id]
        );
      }
    }

    // 12. Log operation (system_logs — real schema: log_id, txn_id, operation, status, timestamp)
    await pgCli.query(
      `INSERT INTO system_logs(log_id, txn_id, operation, status, "timestamp")
       VALUES ($1,$2,$3,'SUCCESS',NOW())`,
      [logId, txnId, `${orderType}_ORDER order_id=${orderId} stock=${stock.symbol} qty=${qtyInt} price=${priceNum}`]
    );

    // 13. Release lock + commit db_transaction record
    await pgCli.query('DELETE FROM locks WHERE lock_id=$1', [lockId]);
    await pgCli.query(
      `UPDATE database_transactions SET txn_state='COMMITTED', end_time=NOW() WHERE txn_id=$1`,
      [txnId]
    );

    await pgCli.query('COMMIT');

    res.status(201).json({
      message:    `${orderType} order executed successfully.`,
      order_id:   orderId,
      trade_id:   tradeId,
      symbol:     stock.symbol,
      qty:        qtyInt,
      price:      priceNum,
      total,
      new_balance: newBalance,
      pnl,
    });

  } catch (err) {
    await pgCli.query('ROLLBACK').catch(() => {});
    // Best-effort failure log
    try {
      const failLogId = await nextSeq({ query: q => query(q) }, 'log_seq').catch(()=>0);
      await query(
        `INSERT INTO system_logs(log_id, txn_id, operation, status, "timestamp")
         VALUES ($1,NULL,$2,'FAILED',NOW())`,
        [failLogId, `${order_type}_ORDER FAILED: ${err.message}`]
      );
    } catch (_) {}
    console.error('[ORDERS] tx error:', err.message);
    res.status(500).json({ error: 'Order failed. ' + err.message });
  } finally {
    pgCli.release();
  }
});

// ─────────────────────────────────────────────────────────────────
// GET /api/orders  — order history for current user
// ─────────────────────────────────────────────────────────────────
router.get('/', requireAuth, async (req, res) => {
  const { status, limit = 50 } = req.query;
  try {
    let sql = `
      SELECT o.order_id, o.stock_id, s.symbol, s.company_name,
             o.order_type, o.order_price, o.quantity,
             o.order_price * o.quantity AS total,
             o.order_status, o.created_at
      FROM   orders o
      JOIN   stocks s ON s.stock_id = o.stock_id
      WHERE  o.user_id = $1
    `;
    const params = [req.user.id];
    if (status) { sql += ` AND upper(o.order_status)=$${params.length+1}`; params.push(status.toUpperCase()); }
    sql += ` ORDER BY o.created_at DESC LIMIT $${params.length+1}`;
    params.push(parseInt(limit));
    const { rows } = await query(sql, params);
    res.json({ orders: rows });
  } catch (e) {
    console.error('[ORDERS GET]', e.message);
    res.status(500).json({ error: 'Failed to fetch orders.' });
  }
});

// ─────────────────────────────────────────────────────────────────
// GET /api/orders/trades  — trade history (join orders for user_id)
// ─────────────────────────────────────────────────────────────────
router.get('/trades', requireAuth, async (req, res) => {
  try {
    const { rows } = await query(`
      SELECT t.order_id, t.trade_id, s.symbol, s.company_name,
             o.order_type AS trade_type,
             t.executed_quantity AS qty,
             t.executed_price    AS price,
             t.executed_price * t.executed_quantity AS total,
             t.trade_time AS executed_at,
             -- P&L: only meaningful for SELL (approximation from portfolio avg)
             CASE WHEN o.order_type='SELL'
               THEN (t.executed_price - COALESCE(
                 (SELECT avg_buy_price FROM portfolio WHERE user_id=o.user_id AND stock_id=o.stock_id LIMIT 1),
                 t.executed_price
               )) * t.executed_quantity
             ELSE 0 END AS pnl
      FROM   trades t
      JOIN   orders o ON o.order_id = t.order_id
      JOIN   stocks s ON s.stock_id = o.stock_id
      WHERE  o.user_id = $1
      ORDER  BY t.trade_time DESC
      LIMIT  100
    `, [req.user.id]);
    res.json({ trades: rows });
  } catch (e) {
    console.error('[TRADES]', e.message);
    res.status(500).json({ error: 'Failed to fetch trades.' });
  }
});

// ─────────────────────────────────────────────────────────────────
// DELETE /api/orders/:id  — cancel an open order
// ─────────────────────────────────────────────────────────────────
router.delete('/:id', requireAuth, async (req, res) => {
  const pgCli = await getClient();
  try {
    await pgCli.query('BEGIN');
    const { rows } = await pgCli.query(
      `UPDATE orders SET order_status='CANCELLED'
       WHERE order_id=$1 AND user_id=$2 AND upper(order_status)='PENDING'
       RETURNING *`,
      [req.params.id, req.user.id]
    );
    if (!rows.length) {
      await pgCli.query('ROLLBACK');
      return res.status(404).json({ error: 'Order not found or not cancellable.' });
    }
    const logId = await nextSeq(pgCli, 'log_seq');
    await pgCli.query(
      `INSERT INTO system_logs(log_id, txn_id, operation, status, "timestamp")
       VALUES ($1,NULL,$2,'SUCCESS',NOW())`,
      [logId, `CANCEL_ORDER order_id=${req.params.id}`]
    );
    await pgCli.query('COMMIT');
    res.json({ message: 'Order cancelled.', order: rows[0] });
  } catch (e) {
    await pgCli.query('ROLLBACK');
    res.status(500).json({ error: 'Failed to cancel order.' });
  } finally { pgCli.release(); }
});

module.exports = router;
